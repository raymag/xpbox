<!DOCTYPE html>
<!-- alt + click = insert cursor -->
<!-- ctrl + b = Toggle sidebar visibility -->
<html lang="pt-br">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="utf-8">
<meta name="author" content="Raymag">
<title>Baú da Escola - Início</title>
<link rel="stylesheet" href="css/padrao.css">
<?php
echo "<style>";
$i = rand(1, 20);
echo '  body{background-image: url("images/Purple/i'.$i.'.jpg")}';
echo "</style>";
?>
</head>
<body>
    <?php
    include "components/posts-manager.php";
    include "components/menu.php";
    ?>
    <section id="sidebar">
        <img src="images/menu.png">
    </section>

    <div id="global-div">
        <?php
        for ($i=0;$i<6;$i++){
            include "components/post-pattern.php";
        }
        ?>
    </div>
</body>
</html>