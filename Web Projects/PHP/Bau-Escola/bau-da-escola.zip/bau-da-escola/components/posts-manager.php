<?php
$host = "localhost";
$user = "root";
$passwd = "";
$db = "bauescola";

$con = mysqli_connect($host, $user, $passwd, $db);

$sql = "SELECT id FROM posts";
$query = mysqli_query($con, $sql);
if(mysqli_num_rows($query)>0){
    $rows = mysqli_fetch_row($query);
    foreach($rows as $rowkey => $rowvalue){
            echo "<script>console.log(".'"'.$rowvalue.'"'.")</script>";
            // echo "$i";
    }
    // echo "<script>console.log(".'"'.$rows[1].'"'.")</script>";
}


if(!$con){
    die(mysqli_connect_error());
}else{
    //erro
}
mysqli_close($con);
?>