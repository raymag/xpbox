<section class="section-div">
            <h4>Lorem ipsum</h4>
            <div id="post-data">
            <p class="post-date">09-06-2018 </p>
            <p class="post-author">Somebody </p>
            </div>
            <br>
            <hr>
            <p><br>
                <img src="images/back1.jpg" width="250">
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quod eaque et cumque nemo dicta iste hic deserunt, nisi accusamus fugit aut culpa molestias necessitatibus optio. Recusandae iste obcaecati dolores culpa.
                Eaque dolorum, vel possimus iure aut fugit voluptatibus minima labore perferendis illum est ipsa sed repellendus reiciendis numquam omnis corrupti incidunt voluptates voluptas tempore maxime cum. Officia aut corrupti quod?
                Recusandae fugiat similique sequi hic incidunt labore libero eveniet voluptatibus delectus cupiditate unde voluptates dolorum, eum ullam doloremque temporibus numquam inventore modi ratione! Quidem velit, laborum ea maiores in blanditiis.
                Culpa non quibusdam distinctio aspernatur enim quae animi accusamus facilis placeat minus ipsum ex nihil dolorem dolore, accusantium labore consectetur! Perspiciatis voluptas, molestiae assumenda est ut exercitationem magni error voluptatibus.
                Quod, numquam quam ea maxime voluptatem obcaecati magnam dolorem praesentium, ipsum, natus officia quisquam consequatur doloribus necessitatibus provident exercitationem assumenda inventore totam eos quibusdam voluptas facilis saepe quos! Similique, rem.
            </p>
        </section>
<?php

?>