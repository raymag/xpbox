<nav id="menu">
<h2><a href="index.php">Baú da Escola</a></h2>
<?php
    echo "<script> 
    var menulink = document.createElement('link');
     menulink.rel='stylesheet';menulink.href='css/menu.css';var head = document.head.appendChild(menulink) </script>";
?>
</nav>